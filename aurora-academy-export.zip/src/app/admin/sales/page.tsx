"use client";

import { useEffect, useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, DollarSign, Calendar, CheckCircle, XCircle, Clock, TrendingUp, CreditCard, ShoppingCart, Pencil, Save, RotateCcw } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SalesGoalWidget } from "./SalesGoalWidget";

interface Sale {
    id: string;
    amount: string;
    status: string;
    createdAt: string;
    user: { name: string; email: string };
    course?: { title: string };
    bundle?: { title: string };
    paymentId: string;
}

export default function AdminSalesPage() {
    const [sales, setSales] = useState<Sale[]>([]);
    const [subStats, setSubStats] = useState<{ total: number, active: number, cancelled: number, churnRate: number, cancelledEmails?: string[] }>({ total: 0, active: 0, cancelled: 0, churnRate: 0, cancelledEmails: [] });
    const [isLoading, setIsLoading] = useState(true);
    const [period, setPeriod] = useState("all");
    const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
    const [timeAgo, setTimeAgo] = useState("Actualizando...");

    const fetchSales = async () => {
        if (!lastUpdated) setIsLoading(true);
        try {
            const res = await fetch(`/api/admin/sales?period=${period}`);
            if (res.ok) {
                const data = await res.json();
                // Check if response is the new object format or old array (backward compat if needed)
                const salesData: Sale[] = Array.isArray(data) ? data : data.sales;
                const subsData = data.subscriptions || { total: 0, active: 0, cancelled: 0, churnRate: 0 };

                setSubStats(subsData);

                // --- SOFT DEDUPLICATION LOGIC ---
                const uniqueSales: Sale[] = [];
                const seen = new Set<string>();

                salesData.forEach(sale => {
                    const itemId = sale.course?.title || sale.bundle?.title || "unknown";
                    const key = `${sale.user.email}-${itemId}-${sale.amount}`;
                    const timeBucket = new Date(sale.createdAt).getTime();

                    const isDuplicate = uniqueSales.some(existing => {
                        const existingKey = `${existing.user.email}-${existing.course?.title || existing.bundle?.title || "unknown"}-${existing.amount}`;
                        if (existingKey !== key) return false;
                        const timeDiff = Math.abs(new Date(existing.createdAt).getTime() - new Date(sale.createdAt).getTime());
                        return timeDiff < 60000;
                    });

                    if (!isDuplicate) {
                        uniqueSales.push(sale);
                    }
                });

                // --- NOTIFICATION LOGIC ---
                // We compare the new sales list with the previous state (or a ref) to detect new items.
                // Since this runs every 60s, it works as a poor-man's websocket.

                // Only run check if not first load (to avoid spamming on refresh)
                if (lastUpdated) {
                    const existingIds = new Set(sales.map(s => s.id));
                    const newSalesFound = uniqueSales.filter(s => !existingIds.has(s.id));

                    if (newSalesFound.length > 0) {
                        // Play sound (optional, browser might block)
                        // const audio = new Audio('/sounds/cash.mp3'); audio.play().catch(e => {});

                        // Show Toast
                        if (newSalesFound.length === 1) {
                            const newSale = newSalesFound[0];
                            const itemName = newSale.course?.title || newSale.bundle?.title || "Producto";
                            toast.success(`¡Nueva venta! $${Number(newSale.amount).toLocaleString('es-AR')}`, {
                                description: `${newSale.user.name} compró ${itemName}`,
                                duration: 8000,
                            });
                        } else {
                            toast.success(`¡${newSalesFound.length} Nuevas ventas!`, {
                                description: `Has generado ingresos recientes.`,
                                duration: 8000,
                            });
                        }
                    }
                }

                setSales(uniqueSales);
                setLastUpdated(new Date());
            }
        } catch (error) {
            console.error("Failed to fetch sales", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchSales();
        const interval = setInterval(fetchSales, 60000);
        return () => clearInterval(interval);
    }, [period]);

    useEffect(() => {
        const timer = setInterval(() => {
            if (lastUpdated) {
                const diff = Math.floor((new Date().getTime() - lastUpdated.getTime()) / 1000);
                if (diff < 60) setTimeAgo(`Actualizado hace ${diff} seg`);
                else if (diff < 3600) setTimeAgo(`Actualizado hace ${Math.floor(diff / 60)} min`);
                else setTimeAgo(`Actualizado hace ${Math.floor(diff / 3600)} h`);
            }
        }, 1000);
        return () => clearInterval(timer);
    }, [lastUpdated]);

    // --- AGGREGATION LOGIC ---
    const chartData = useMemo(() => {
        if (!sales.length) return [];

        const groupedData: Record<string, { date: string; amount: number; count: number }> = {};

        sales.forEach(sale => {
            if (sale.status !== 'approved') return; // Only count approved revenue

            const date = new Date(sale.createdAt);
            let key = '';
            let label = '';

            if (period === 'today') {
                key = `${date.getHours()}:00`;
                label = `${date.getHours()}:00`;
            } else if (period === 'month' || period === 'week') {
                key = date.toLocaleDateString("es-AR", { day: '2-digit', month: '2-digit' });
                label = key;
            } else {
                // All time: Group by Month if too many, or Week? Let's do Month for All.
                key = date.toLocaleDateString("es-AR", { month: 'short', year: '2-digit' });
                label = key;
            }

            if (!groupedData[key]) {
                groupedData[key] = { date: label, amount: 0, count: 0 };
            }
            groupedData[key].amount += Number(sale.amount);
            groupedData[key].count += 1;
        });

        // Convert to array and sort
        const result = Object.values(groupedData);
        // We need to sort by date. But keys are strings. 
        // Quick fix: user sales array order (it is DESC). we reverse it for chart (ASC).
        // A robust way is to re-sort:
        // Actually, since we iterate linearly over sorted sales, we might construct it in reverse or sort later.
        // Let's rely on sales being DESC, so we process latest first. 
        // We should reverse the final array so graph goes Left->Right (Old->New).
        return result.reverse();
    }, [sales, period]);

    const totalRevenue = sales.filter(s => s.status === 'approved').reduce((acc, s) => acc + Number(s.amount), 0);
    const totalTransactions = sales.filter(s => s.status === 'approved').length;

    // Exclude free items (amount 0) from average ticket calculation
    const paidTransactions = sales.filter(s => s.status === 'approved' && Number(s.amount) > 0).length;
    const avgTicket = paidTransactions > 0 ? totalRevenue / paidTransactions : 0;


    const formatCurrency = (amount: string | number) => {
        return new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS" }).format(Number(amount));
    };

    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString("es-AR", {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        });
    };

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'approved': return <Badge variant="success" className="gap-1"><CheckCircle size={10} /> Aprobado</Badge>;
            case 'rejected': return <Badge variant="destructive" className="gap-1"><XCircle size={10} /> Rechazado</Badge>;
            case 'refunded':
            case 'refund': return <Badge variant="outline" className="gap-1 border-orange-500 text-orange-500 bg-orange-500/10"><RotateCcw size={10} /> Reembolsado</Badge>;
            default: return <Badge variant="warning" className="gap-1"><Clock size={10} /> Pendiente</Badge>;
        }
    };

    const periodLabel = { 'today': 'Hoy', 'week': 'Esta Semana', 'month': 'Este Mes', 'all': 'Histórico' }[period] || 'Periodo';

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white">Dashboard de Ventas</h1>
                    {lastUpdated && <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><Clock size={10} /> {timeAgo}</p>}
                </div>
                <div className="flex items-center gap-2 bg-[#1F2937] p-1 rounded-lg border border-gray-700">
                    {['today', 'week', 'month', 'all'].map(p => (
                        <button key={p} onClick={() => setPeriod(p)} className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${period === p ? 'bg-[#5D5CDE] text-white' : 'text-gray-400 hover:text-white'}`}>
                            {{ 'today': 'Hoy', 'week': 'Semana', 'month': 'Mes', 'all': 'Histórico' }[p]}
                        </button>
                    ))}
                </div>
            </div>

            {/* SALES GOAL WIDGET */}
            <div className="mb-6">
                <SalesGoalWidget />
            </div>

            {/* METRICS GRID */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-r from-[#1F2937] to-[#111827] border-gray-700">
                    <CardContent className="p-6">
                        <div className="flex justify-between items-start gap-4">
                            <div className="min-w-0 flex-1">
                                <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Ingresos Totales</p>
                                <h2 className="text-2xl font-bold text-white mt-2 truncate" title={formatCurrency(totalRevenue)}>
                                    {formatCurrency(totalRevenue)}
                                </h2>
                            </div>
                            <div className="bg-emerald-500/10 p-3 rounded-full flex-shrink-0"><DollarSign className="text-emerald-400 h-6 w-6" /></div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-[#1F2937] border-gray-700">
                    <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Transacciones</p>
                                <h2 className="text-2xl font-bold text-white mt-2">{totalTransactions}</h2>
                            </div>
                            <div className="bg-blue-500/10 p-3 rounded-full"><ShoppingCart className="text-blue-400 h-6 w-6" /></div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-[#1F2937] border-gray-700">
                    <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Ticket Promedio</p>
                                <h2 className="text-2xl font-bold text-white mt-2">{formatCurrency(avgTicket)}</h2>
                            </div>
                            <div className="bg-purple-500/10 p-3 rounded-full"><TrendingUp className="text-purple-400 h-6 w-6" /></div>
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-[#1F2937] border-gray-700">
                    <CardContent className="p-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <p className="text-gray-400 text-xs font-medium uppercase tracking-wider">Churn Rate (Bajas)</p>
                                <h2 className="text-2xl font-bold text-white mt-2">{subStats.churnRate.toFixed(1)}%</h2>
                                <div className="group relative">
                                    <p className="text-[10px] text-gray-500 mt-1 cursor-help hover:text-gray-300 transition-colors">
                                        {subStats.cancelled} bajas / {subStats.total} total
                                    </p>
                                    {subStats.cancelledEmails && subStats.cancelledEmails.length > 0 && (
                                        <div className="absolute top-full left-0 mt-2 z-50 w-64 p-3 bg-gray-900 border border-gray-700 rounded-lg shadow-xl hidden group-hover:block">
                                            <p className="text-xs font-semibold text-gray-400 mb-2">Usuarios baja:</p>
                                            <ul className="space-y-1">
                                                {subStats.cancelledEmails.map((email: string, idx: number) => (
                                                    <li key={idx} className="text-xs text-gray-300 truncate">{email}</li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="bg-rose-500/10 p-3 rounded-full"><XCircle className="text-rose-400 h-6 w-6" /></div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* CHART */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2 bg-[#1F2937] border-gray-700">
                    <CardHeader><CardTitle className="text-white text-lg">Tendencia de Ingresos</CardTitle></CardHeader>
                    <CardContent className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={chartData}>
                                <defs>
                                    <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#5D5CDE" stopOpacity={0.8} />
                                        <stop offset="95%" stopColor="#5D5CDE" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                                <XAxis dataKey="date" stroke="#9CA3AF" tick={{ fontSize: 12 }} />
                                <YAxis stroke="#9CA3AF" tick={{ fontSize: 12 }} tickFormatter={(value) => `$${value / 1000}k`} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#111827', borderColor: '#374151', color: 'white' }}
                                    formatter={(value: any) => [formatCurrency(value), 'Ingresos']}
                                />
                                <Area type="monotone" dataKey="amount" stroke="#5D5CDE" fillOpacity={1} fill="url(#colorAmount)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* DISTRIBUTION / STATUS OR TOP ITEMS? For now simple list or pie? Keep it simple. */}
                <Card className="bg-[#1F2937] border-gray-700">
                    <CardHeader><CardTitle className="text-white text-lg">Resumen de Actividad</CardTitle></CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-3 gap-4 text-center">
                            <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-[#374151]/10 border border-gray-700/50">
                                <span className="text-emerald-400 font-bold text-2xl">{sales.filter(s => s.status === 'approved').length}</span>
                                <span className="text-gray-400 text-xs mt-1">Aprobadas</span>
                            </div>
                            <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-[#374151]/10 border border-gray-700/50">
                                <span className="text-rose-400 font-bold text-2xl">{sales.filter(s => s.status === 'rejected').length}</span>
                                <span className="text-gray-400 text-xs mt-1">Rechazadas</span>
                            </div>
                            <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-[#374151]/10 border border-gray-700/50">
                                <span className="text-amber-400 font-bold text-2xl">{sales.filter(s => s.status === 'pending').length}</span>
                                <span className="text-gray-400 text-xs mt-1">Pendientes</span>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* TABLE */}
            <Card className="bg-[#1F2937] border-gray-700">
                <CardHeader>
                    <CardTitle className="text-white text-lg">Detalle de Transacciones</CardTitle>
                </CardHeader>
                <CardContent>
                    {isLoading ? (
                        <div className="flex justify-center py-12">
                            <Loader2 className="animate-spin text-primary h-8 w-8" />
                        </div>
                    ) : sales.length === 0 ? (
                        <div className="text-center py-12 text-gray-500">
                            No se encontraron transacciones en este periodo.
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="text-xs text-gray-400 bg-[#111827] uppercase">
                                    <tr>
                                        <th className="px-4 py-3 rounded-tl-lg">Ítem</th>
                                        <th className="px-4 py-3">Usuario</th>
                                        <th className="px-4 py-3">Monto</th>
                                        <th className="px-4 py-3">Estado</th>
                                        <th className="px-4 py-3">Fecha</th>
                                        <th className="px-4 py-3 rounded-tr-lg">ID</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sales.map((sale) => (
                                        <tr key={sale.id} className="border-b border-gray-800 hover:bg-[#111827]/50 transition-colors group">
                                            <td className="px-4 py-3 font-medium text-white max-w-[200px] truncate" title={sale.course?.title || sale.bundle?.title}>
                                                {sale.course?.title || sale.bundle?.title || "Ítem desconocido"}
                                            </td>
                                            <td className="px-4 py-3">
                                                <div className="flex flex-col">
                                                    <span className="text-gray-300">{sale.user.name || "Sin nombre"}</span>
                                                    <span className="text-gray-500 text-xs">{sale.user.email}</span>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 font-bold text-emerald-400">
                                                <div className="flex items-center gap-2">
                                                    {formatCurrency(sale.amount)}
                                                    <EditAmountButton sale={sale} onUpdate={fetchSales} />
                                                </div>
                                            </td>
                                            <td className="px-4 py-3">{getStatusBadge(sale.status)}</td>
                                            <td className="px-4 py-3 text-gray-400 whitespace-nowrap">{formatDate(sale.createdAt)}</td>
                                            <td className="px-4 py-3 text-gray-500 font-mono text-xs max-w-[100px] truncate" title={sale.paymentId}>{sale.paymentId}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
function EditAmountButton({ sale, onUpdate }: { sale: Sale; onUpdate: () => void }) {
    const [isOpen, setIsOpen] = useState(false);
    const [amount, setAmount] = useState(sale.amount);
    const [loading, setLoading] = useState(false);

    const handleUpdate = async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/admin/sales/${sale.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ amount }),
            });

            if (res.ok) {
                toast.success("Monto actualizado correctamente");
                onUpdate();
                setIsOpen(false);
            } else {
                toast.error("Error al actualizar monto");
            }
        } catch (error) {
            toast.error("Error de conexión");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 text-[#5D5CDE] hover:text-[#4b4ac0] hover:bg-[#5D5CDE]/10 transition-colors">
                    <Pencil size={14} strokeWidth={2.5} />
                </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#1F2937] border-gray-700 text-white sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Editar Monto de Venta</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="amount" className="text-right text-gray-400">
                            Monto
                        </Label>
                        <Input
                            id="amount"
                            type="number"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            className="col-span-3 bg-black/30 border-gray-600 text-white focus:border-[#5D5CDE]"
                        />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="ghost" onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white">
                        Cancelar
                    </Button>
                    <Button onClick={handleUpdate} disabled={loading} className="bg-[#5D5CDE] hover:bg-[#4b4ac0] text-white">
                        {loading ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                        Guardar Cambios
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
