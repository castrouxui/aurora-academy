"use client";

import { Button } from '@/components/ui/button';

import { Container } from '@/components/layout/Container';
import { CourseCard } from './CourseCard';
import { useEffect, useState } from 'react';
import Link from 'next/link';

export function CourseList() {
    const [ownedCourseIds, setOwnedCourseIds] = useState<string[]>([]);
    const [courses, setCourses] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        async function fetchData() {
            try {
                // 1. Fetch Public Courses
                const coursesRes = await fetch("/api/courses?published=true");

                // 2. Fetch User's Owned Courses (if logged in)
                const myCoursesRes = await fetch("/api/my-courses");
                let myIds: string[] = [];
                if (myCoursesRes.ok) {
                    const myData = await myCoursesRes.json();
                    myIds = myData.map((c: any) => c.id);
                    setOwnedCourseIds(myIds);
                }

                if (coursesRes.ok) {
                    const data = await coursesRes.json();
                    // Transform API data to UI format and take top 4
                    const formattedCourses = data.slice(0, 4).map((course: any) => {
                        const sortedModules = course.modules?.sort((a: any, b: any) => a.position - b.position) || [];
                        const firstLessonWithVideo = sortedModules
                            .flatMap((m: any) => m.lessons?.sort((a: any, b: any) => a.position - b.position) || [])
                            .find((l: any) => l.videoUrl);

                        const basePrice = Number(course.price);
                        const discount = course.discount || 0;
                        const finalPrice = basePrice * (1 - discount / 100);

                        return {
                            id: course.id,
                            title: course.title,
                            instructor: "Aurora Academy",
                            rating: 5.0,
                            reviews: "(120)",
                            price: new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", minimumFractionDigits: 0 }).format(finalPrice),
                            oldPrice: discount > 0
                                ? new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", minimumFractionDigits: 0 }).format(basePrice)
                                : "",
                            discountPercentage: discount > 0 ? discount : undefined,
                            image: course.imageUrl || "/course-placeholder.jpg",
                            tag: course.category || "General",
                            rawPrice: finalPrice,
                            videoUrl: firstLessonWithVideo?.videoUrl || null
                        };
                    });
                    setCourses(formattedCourses);
                }
            } catch (error) {
                console.error("Failed to fetch data", error);
            } finally {
                setIsLoading(false);
            }
        }
        fetchData();
    }, []);

    if (isLoading) {
        return (
            <section className="py-24 bg-[#0B0F19]">
                <Container>
                    <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#5D5CDE]"></div>
                    </div>
                </Container>
            </section>
        );
    }

    if (courses.length === 0) return null;

    return (
        <section className="py-24 bg-[#0B0F19] transition-colors">
            <Container>
                <div className="text-center mb-12 md:mb-16 space-y-4">
                    <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">
                        Potencia tu perfil profesional
                    </h2>
                    <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
                        Programas intensivos diseñados para insertarte en el mercado rápidamente.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {courses.map((course, i) => (
                        <CourseCard key={i} course={course} isOwned={ownedCourseIds.includes(course.id)} />
                    ))}
                </div>

                <div className="mt-16 text-center">
                    <Link href="/cursos">
                        <Button size="lg" className="h-14 px-10 rounded-full bg-[#1F2937] text-white hover:bg-black font-bold text-lg shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1">
                            Explorar todos los cursos
                        </Button>
                    </Link>
                </div>
            </Container>
        </section>
    );
}
